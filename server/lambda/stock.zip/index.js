var AWS = require('aws-sdk');
var http = require('http');

AWS.config.region = 'ap-northeast-2';

const S3_PATH = 'https://autostore.s3.ap-northeast-2.amazonaws.com/'

exports.handler = async (event) => {
  const s3 = new AWS.S3();
  const http = require('http');
  const { requestContext, queryStringParameters } = event;
  const { httpMethod } = requestContext;

  const goods = await http.request({
    hostname: S3_PATH,
    path: 'goods.json',
  });

  var body = {
    httpMethod,
    queryStringParameters,
    goods,
  };

  const response = {
    statusCode: 200,
    body: JSON.stringify(body),
  };

  return response;
};
