const AWS = require('aws-sdk');
const http = require('http');
const fetch = require('node-fetch');
AWS.config.region = 'ap-northeast-2';
const S3_PATH = 'https://autostore.s3.ap-northeast-2.amazonaws.com/'

const s3 = new AWS.S3({
  accessKeyId: 'AKIAIIZH3KTFD7P2FLJQ',
  secretAccessKey: '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',
});

exports.handler = async (event) => {
  const http = require('http');
  const { requestContext, queryStringParameters } = event;
  const { httpMethod } = requestContext;
  var statusCode = 200;
  var body = {};
  var res = null;
  try{
    let customer = await fetch(S3_PATH+'customer.json');
    customer = await customer.json();
    let goods = await fetch(S3_PATH + 'goods.json');
    goods = await goods.json();

    const { goodsID, customerID } = event;
    let timer = new Date();
    let currentTime = timer.getFullyear() + '년 ' + (timer.getMonth() + 1) + '월 '
    + timer.getDate() + '일 ' + timer.getHours() + '시 ' + timer.getMinutes() + '분 ' + timer.getSeconds() + '초 ';

    body.goodsID = goodsID;
    body.customerID = customerID;
    body.message = `도난 감지 : ${customer.id.name}` + '감지 시간 : ' + currentTime;


    res = await s3.putObject({
      Bucket: 'autostore',
      Key: 'anti-theft-management.json',
      Body: JSON.stringify(currentTime) + JSON.stringify(goodsID) + JSON.stringify(customerID),
      ACL:'public-read',
    }).promise();
  }
  catch(e) {
    statusCode = 401;
    body.message = e;
  }
  finally {
    const response = {
      statusCode,
      body: JSON.stringify(body),
    };

    return response;
  }
};
